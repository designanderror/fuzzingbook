This Python package holds various utilities for notebooks, 
in particular functionality that notebooks can import each other.
